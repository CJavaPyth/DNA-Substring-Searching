file_name = "GCA_20MB_009859145.1_Andalucia_godoyi_V16_genomic.fna"

print("Running...")

file = open(file_name, "r+")
f1 = file.read()
f1

f2_uppercase = f1.upper()
f3_new = ''
for i in f2_uppercase:
    if ((i == "A" or i == "T" or i == "G" or i == "C" or i == "U") and (i.isalnum)):
        f3_new += i

#print(f3_new)
file.close()
f3_new

file_example2 = open (file_name, "w")
file_example2.write(f3_new)
file_example2.close()
print("Finished")
