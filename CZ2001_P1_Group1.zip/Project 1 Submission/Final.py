import timeit
file_name = "GCF_3.5_MB_003966975.1_ASM396697v1_genomic.fna"
f = open(file_name, "r")
text1 = f.read()
pattern = 'TATATA'
dict_hash = {'A':1, 'T':2, 'C':3, 'G':4, 'U':5}
text1 = text1.replace('\n', '')
size_of_hash_table = 7919
weight_multiplier = 2

#generating the hash_table
def hash_table_generation (text, pattern):
    hash_table = []
    for i in range(size_of_hash_table):
        hash_table.append([])
    
    hash_value = 0
    weight = 1
    for i in range(len(pattern)):
        temp = dict_hash.get(text[i])
        hash_value += temp * weight
        weight *= weight_multiplier

    hash_temp = hash_value
    
    while (hash_value >= size_of_hash_table):
        hash_value = hash_value % size_of_hash_table

    hash_table[hash_value].append(0)    
    final_weight = int (weight/weight_multiplier)

    for i in range (1,len(text)-len(pattern)+1):             
        temp = dict_hash.get(text[i-1])
        hash_temp -= temp
        hash_temp = int(hash_temp/weight_multiplier)
        temp = dict_hash.get(text[i+len(pattern)-1])
        hash_temp += final_weight * temp
        hash_value = hash_temp
        while (hash_value >= size_of_hash_table):
            hash_value = hash_value % size_of_hash_table
        hash_table[hash_value].append(i)

    return hash_table

def cal_hash_target(pattern):
    weight = 1
    hash_target = 0
    for i in range(len(pattern)):
        temp = dict_hash.get(pattern[i])
        hash_target += temp * weight
        weight *= weight_multiplier
    
    while (hash_target >= size_of_hash_table):
        hash_target = hash_target % size_of_hash_table
    return hash_target

def timer(func,*args):
	start = timeit.default_timer()
	func(*args)
	stop = timeit.default_timer()
	print('Time: ', stop - start, '\n')

def static_hash(hash_table, hash_target, pattern, text):
    position_list = hash_table[hash_target]
    actual_list = []
    patternLength = len(pattern)
    for i in position_list:
        matched = True
        for j in range(patternLength):
            if (pattern[j] != text[i+j]):
                matched = False
                break
        if (matched == True):
            actual_list.append(i+1)
    print(actual_list)

def bruteforce(pattern, text):
	patternLength = len(pattern)
	textLength = len(text)
	positionList = []
	match = True
	for y in range(textLength - patternLength + 1):
		for x in range(patternLength):
			if pattern[x] != text[x+y]:
				match = False
			if match == False:
				break
		if match:
			positionList += [y+1]
		else:
			match = True
	print(positionList)
  
  
def getpatternFA(pattern, M):  
    FA = [{'A':0,'T':0,'C':0,'G':0,'U':0} for _ in range(M+1)] 
    longestprefixsuffix = 0
    FA[0][pattern[0]] =1    
    for i in range(1,M+1):
        for x in 'ATCGU':
             FA[i][x] = FA[longestprefixsuffix][x]

        if i < M:
            FA[i][pattern[i]] = i + 1
            longestprefixsuffix = FA[longestprefixsuffix][pattern[i]] 
    return FA 
  
def fasearch(pattern, text): 
    M = len(pattern) 
    N = len(text) 
    FA = getpatternFA(pattern, M) #make FA of pattern string 
    pos_list = []   
    state=0
    for i in range(N): 
        state = FA[state][text[i]] #find new state based on text character 
        if state == M: 
            pos_list+=[i-M+2]# if state = pattern length, means terminal state has been reached and occurence is found, backtrack to position of first character of the string (i-M+1) and i added 1 for consistency, so (i-M+1+1))
    print(pos_list)

while True:

    print("length of the text:", len(text1))
    print("length of the pattern:" ,len(pattern))
    hash_table = hash_table_generation(text1, pattern)
    hash_target = cal_hash_target(pattern)
    print("Bruteforce:")
    timer(bruteforce,pattern,text1)
    print("generating the hash table:")
    timer(hash_table_generation, text1, pattern)
    print("generating the hash target:")
    timer(cal_hash_target,pattern)
    print("static_hash:")
    timer(static_hash, hash_table, hash_target, pattern, text1)
    print('finite state:')
    timer(fasearch, pattern, text1)
    pattern = input('Enter new string or 0 to quit:')
    if pattern == '0':
        print('Goodbye!')
        break

